package com.dh.clinicaPinerosGarcia.model;

public enum UsuarioRol {
    USER,ADMIN
}
